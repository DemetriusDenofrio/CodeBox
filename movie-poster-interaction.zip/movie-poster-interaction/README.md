# Movie Poster Interaction

A Pen created on CodePen.io. Original URL: [https://codepen.io/pleasedonotdisturb/pen/oNQLVXB](https://codepen.io/pleasedonotdisturb/pen/oNQLVXB).

An iMDB concept for movie cards. Side note: the movies seen in the demo doesn’t exist (I made the posters by myself using GIMP)!

[View Source Code]()